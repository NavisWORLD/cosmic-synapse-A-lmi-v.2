using UnityEngine;

public class CSTEntityData : MonoBehaviour
{
    public CSTEntity cstEntity; // Stores the CSTEntity data for this GameObject
}