export function init({ bus, scene, THREE }) {
  function lightning({ at, length = 200, intensity = 1 }) {
    const segs = 140;
    const geo = new THREE.BufferGeometry();
    const arr = new Float32Array(segs * 6);
    const origin = new THREE.Vector3(at.x || 0, at.y || 0, at.z || 0);
    for (let i = 0; i < segs; i++) {
      const a = origin.clone().add(new THREE.Vector3((Math.random() - 0.5) * length, (Math.random() - 0.5) * length, (Math.random() - 0.5) * length));
      const b = a.clone().add(new THREE.Vector3((Math.random() - 0.5) * 40, (Math.random() - 0.5) * 40, (Math.random() - 0.5) * 40));
      arr.set([a.x, a.y, a.z, b.x, b.y, b.z], i * 6);
    }
    geo.setAttribute('position', new THREE.BufferAttribute(arr, 3));
    const mat = new THREE.LineBasicMaterial({ color: 0x7aa2ff, transparent: true, opacity: Math.min(1, 0.6 * intensity) });
    const lines = new THREE.LineSegments(geo, mat);
    scene.add(lines);
    setTimeout(() => { scene.remove(lines); geo.dispose(); mat.dispose(); }, 1000 + Math.random() * 600);
  }

  bus.on('universe:triggerEvent', (e) => {
    const ev = e?.event || e;
    if (!ev || !ev.kind) return;
    if (ev.kind === 'lightning') lightning(ev);
  });

  return { stop: () => {} };
}


