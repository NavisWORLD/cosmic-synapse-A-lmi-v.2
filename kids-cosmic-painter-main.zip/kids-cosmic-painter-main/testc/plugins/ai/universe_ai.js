export function init({ bus, rngSeed = 12345 } = {}) {
  let lastAction = 0;
  let time = 0;
  // simple LCG
  let s = rngSeed >>> 0;
  const rnd = () => (s = (1664525 * s + 1013904223) >>> 0) / 0xffffffff;
  const profile = { likesNebula: 0.5, likesStars: 0.5 };

  function decide(state) {
    const now = time;
    const cool = 6 + Math.floor(6 * (1 - Math.min(1, state.psd || 0)));
    if (now - lastAction < cool) return null;
    const novelty = rnd();
    if (novelty < 0.4) return { type: 'spawn_star' };
    if (novelty < 0.75) return { type: 'spawn_planet' };
    return { type: 'cosmic_storm' };
  }

  bus.on('engine:tick', (e) => {
    time += e?.dt || 0;
    const state = { psd: e?.psd || 0 };
    const action = decide(state);
    if (!action) return;
    lastAction = time;
    if (action.type === 'spawn_star') bus.emit('universe:spawnObject', { type: 'star', source: 'ai' });
    else if (action.type === 'spawn_planet') bus.emit('universe:spawnObject', { type: 'planet', source: 'ai' });
    else if (action.type === 'cosmic_storm') bus.emit('universe:triggerEvent', { event: { kind: 'lightning', at: { x: 0, y: 0, z: 0 }, intensity: 1 } });
  });

  return { stop: () => {} };
}


