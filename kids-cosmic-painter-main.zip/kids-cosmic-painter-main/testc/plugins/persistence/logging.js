export function init({ bus, logElId = 'log' } = {}) {
  const el = document.getElementById(logElId);
  function uiLog(evt, payload) {
    if (!el) return;
    const ts = new Date().toLocaleTimeString();
    const text = typeof payload === 'object' ? JSON.stringify(payload) : String(payload ?? '');
    const line = `<div><span class=ts>[${ts}]</span> <span class=evt>${evt}</span> <span class=pl>${text}</span></div>`;
    el.insertAdjacentHTML('beforeend', line);
    el.scrollTop = el.scrollHeight;
  }
  const sub = bus && typeof bus.on === 'function' ? bus.on.bind(bus) : null;
  if (sub) {
    const events = [
      'universe:spawnObject',
      'engine:tick',
      'sensory:voice:command',
      'control:ship:changeSpeed',
      'control:ship:applyRotation'
    ];
    events.forEach((ev) => sub(ev, (p) => uiLog(ev, p)));
  }
  return { stop: () => {} };
}


