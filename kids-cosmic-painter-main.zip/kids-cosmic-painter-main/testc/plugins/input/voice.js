export function init({ bus, lang = 'en-US' } = {}) {
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SR) return { stop: () => {} };
  const rec = new SR();
  rec.lang = lang;
  rec.continuous = true;
  rec.interimResults = false;

  function handle(transcript) {
    const s = String(transcript || '').toLowerCase();
    try { bus.emit && bus.emit('sensory:voice:command', { transcript: s }); } catch {}
    try {
      if (s.includes('spawn') && s.includes('planet')) {
        bus.emit('universe:spawnObject', { type: 'planet', position: 'ahead', source: 'voice' });
        return;
      }
      if (s.includes('spawn') && s.includes('star')) {
        bus.emit('universe:spawnObject', { type: 'star', source: 'voice' });
        return;
      }
      if (s.includes('black hole') || s.includes('blackhole')) {
        bus.emit('universe:spawnObject', { type: 'blackhole', source: 'voice' });
        return;
      }
      if (s.includes('increase') && s.includes('speed')) {
        bus.emit('control:ship:changeSpeed', { delta: +0.12 });
        return;
      }
      if (s.includes('decrease') && s.includes('speed')) {
        bus.emit('control:ship:changeSpeed', { delta: -0.12 });
        return;
      }
    } catch {}
  }

  rec.onresult = (e) => {
    try {
      const res = e.results[e.results.length - 1];
      const t = res && res[0] && res[0].transcript;
      if (t) handle(t);
    } catch {}
  };
  rec.onerror = () => {};
  try { rec.start(); } catch {}
  return { stop: () => { try { rec.stop(); } catch {} } };
}


