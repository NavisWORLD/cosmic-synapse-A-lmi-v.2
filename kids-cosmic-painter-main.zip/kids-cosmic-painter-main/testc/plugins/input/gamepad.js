export function init({ bus, deadzone = 0.15 } = {}) {
  let connectedId = null;
  const curve = (v) => {
    const a = Math.abs(v);
    if (a < deadzone) return 0;
    const n = (a - deadzone) / (1 - deadzone);
    return Math.sign(v) * n * n * n;
  };
  function poll() {
    const pads = navigator.getGamepads ? navigator.getGamepads() : [];
    const gp = pads && pads[0];
    if (!gp) return;
    if (!connectedId) connectedId = gp.id;
    const ax = gp.axes || [];
    const btn = gp.buttons || [];
    const pitch = -curve(ax[1] || 0);
    const yaw = curve(ax[0] || 0);
    const roll = curve(ax[2] || 0);
    const throttle = (btn[7]?.value || 0) - (btn[6]?.value || 0);
    try {
      bus.emit('sensory:gamepad:state', { id: gp.id, axes: ax, connected: gp.connected, mapping: gp.mapping });
      bus.emit('control:ship:applyRotation', { pitch, yaw, roll });
      if (Math.abs(throttle) > 0.001) bus.emit('control:ship:changeSpeed', { delta: throttle * 0.8 });
    } catch {}
  }
  let raf = 0;
  function loop() { poll(); raf = requestAnimationFrame(loop); }
  raf = requestAnimationFrame(loop);
  return { stop: () => { try { cancelAnimationFrame(raf); } catch {} } };
}


