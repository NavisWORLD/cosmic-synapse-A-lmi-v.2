# cosmic-compressor
GX-ψ (GXPSI) is a complete lossless compression framework featuring DP-16 optimal parsing, content-defined chunking, deduplication, dictionary encoding, and AES-GCM encryption. This project brings the full blueprint to life with a production-ready web implementation that achieves excellent compression ratios.
