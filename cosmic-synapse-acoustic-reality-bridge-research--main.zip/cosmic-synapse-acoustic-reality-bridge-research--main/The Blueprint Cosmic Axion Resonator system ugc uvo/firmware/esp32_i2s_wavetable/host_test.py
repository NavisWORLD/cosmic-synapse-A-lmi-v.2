#!/usr/bin/env python3
"""host_test.py
Simple host script to connect to ESP32 via serial, send JSON commands, and log telemetry lines to CSV.
Usage: python host_test.py /dev/ttyUSB0 115200 output.csv
"""
import sys, serial, time, json, csv

def usage():
    print('Usage: python host_test.py PORT BAUD OUTPUT_CSV')
    sys.exit(1)

if len(sys.argv) < 4:
    usage()

port = sys.argv[1]
baud = int(sys.argv[2])
outfile = sys.argv[3]

ser = serial.Serial(port, baud, timeout=1)
time.sleep(2)  # allow device to reset

def send_cmd(d):
    s = json.dumps(d) + '\n'
    ser.write(s.encode('utf-8'))

# open CSV writer
f = open(outfile, 'w', newline='')
writer = None

try:
    # sample commands: start tone A at 432Hz, amplitude 0.2
    send_cmd({'on':1})
    send_cmd({'fA':432.0, 'aA':0.2})
    send_cmd({'fB':864.0, 'aB':0.1})

    t0 = time.time()
    while True:
        line = ser.readline().decode('utf-8').strip()
        if not line: continue
        try:
            obj = json.loads(line)
        except Exception as e:
            print('NON-JSON:', line)
            continue
        # initialize writer header
        if writer is None:
            keys = sorted(obj.keys())
            writer = csv.DictWriter(f, fieldnames=keys)
            writer.writeheader()
        # write row (flatten)
        writer.writerow({k: obj.get(k,None) for k in obj.keys()})
        f.flush()
        # stop after 30 seconds
        if time.time() - t0 > 30:
            break
finally:
    # stop output
    send_cmd({'on':0})
    time.sleep(0.1)
    ser.close()
    f.close()
    print('Done.')
