\
/*
  ESP32 I2S Wavetable Firmware - with ArduinoJson command parser
  Target: ESP32 DevKitC (ESP32-WROOM-32)
  PlatformIO env: esp32dev (platformio.ini included)
*/

#include <Arduino.h>
#include "driver/i2s.h"
#include "HX711.h"
#include <Wire.h>
#include <Adafruit_Sensor.h>
#include <Adafruit_ADXL345_U.h>
#include <ArduinoJson.h>

// Config
#define SAMPLE_RATE 48000
#define WAVETABLE_SIZE 2048
#define I2S_NUM I2S_NUM_0
#define I2S_BCK_PIN 26
#define I2S_WS_PIN 25
#define I2S_DOUT_PIN 22

// HX711 pins (change as needed)
#define HX_DT 32
#define HX_SCK 33
HX711 scale;

Adafruit_ADXL345_Unified accel = Adafruit_ADXL345_Unified(12345);

// wavetable
static float wavetable[WAVETABLE_SIZE];
static double phaseA = 0.0, phaseB = 0.0;
static double phaseIncA = 0.0, phaseIncB = 0.0;
static float ampA = 0.0f, ampB = 0.0f;
volatile bool outputOn = false;
volatile double freqA = 432.0, freqB = 864.0;
volatile float HX_CAL = 1.0f;

// Serial parsing buffer
String serialBuf;

void i2s_init() {
  i2s_config_t i2s_config = {
    .mode = (i2s_mode_t)(I2S_MODE_MASTER | I2S_MODE_TX),
    .sample_rate = SAMPLE_RATE,
    .bits_per_sample = I2S_BITS_PER_SAMPLE_16BIT,
    .channel_format = I2S_CHANNEL_FMT_RIGHT_LEFT,
    .communication_format = I2S_COMM_FORMAT_I2S_MSB,
    .intr_alloc_flags = 0,
    .dma_buf_count = 6,
    .dma_buf_len = 512,
    .use_apll = false,
    .tx_desc_auto_clear = true
  };
  i2s_driver_install(I2S_NUM, &i2s_config, 0, NULL);
  i2s_pin_config_t pin_config;
  pin_config.bck_io_num = I2S_BCK_PIN;
  pin_config.ws_io_num = I2S_WS_PIN;
  pin_config.data_out_num = I2S_DOUT_PIN;
  pin_config.data_in_num = I2S_PIN_NO_CHANGE;
  i2s_set_pin(I2S_NUM, &pin_config);
}

void init_wavetable() {
  for (uint32_t i=0;i<WAVETABLE_SIZE;i++){
    wavetable[i] = sinf((float)i * (2.0f * PI / (float)WAVETABLE_SIZE));
  }
}

void update_phase_increments(){
  phaseIncA = (double)WAVETABLE_SIZE * (freqA / (double)SAMPLE_RATE);
  phaseIncB = (double)WAVETABLE_SIZE * (freqB / (double)SAMPLE_RATE);
}

int16_t *genBuf = NULL;
const size_t FRAMES_PER_CHUNK = 256;

void generate_and_write_samples(size_t frames) {
  const size_t samples = frames * 2;
  if (!genBuf) {
    genBuf = (int16_t*)malloc(sizeof(int16_t) * samples);
    if (!genBuf) return;
  }
  for (size_t i=0;i<frames;i++){
    uint32_t idxA = ((uint32_t)phaseA) & (WAVETABLE_SIZE-1);
    uint32_t idxB = ((uint32_t)phaseB) & (WAVETABLE_SIZE-1);
    double fracA = phaseA - floor(phaseA);
    double fracB = phaseB - floor(phaseB);
    uint32_t i0A = idxA, i1A = (idxA + 1) & (WAVETABLE_SIZE-1);
    uint32_t i0B = idxB, i1B = (idxB + 1) & (WAVETABLE_SIZE-1);
    float sA = wavetable[i0A] * (1-fracA) + wavetable[i1A] * fracA;
    float sB = wavetable[i0B] * (1-fracB) + wavetable[i1B] * fracB;
    float outA = ampA * sA;
    float outB = ampB * sB;
    genBuf[2*i+0] = (int16_t)(outA * 32767.0f);
    genBuf[2*i+1] = (int16_t)(outB * 32767.0f);
    phaseA += phaseIncA; if (phaseA >= WAVETABLE_SIZE) phaseA -= WAVETABLE_SIZE;
    phaseB += phaseIncB; if (phaseB >= WAVETABLE_SIZE) phaseB -= WAVETABLE_SIZE;
  }
  size_t bytes_written = 0;
  i2s_write(I2S_NUM, (const char*)genBuf, frames * 2 * sizeof(int16_t), &bytes_written, portMAX_DELAY);
}

void handleCommandJson(const String& s) {
  // Parse Json using ArduinoJson (StaticJsonDocument)
  StaticJsonDocument<256> doc;
  DeserializationError err = deserializeJson(doc, s);
  if (err) {
    // parsing failed
    Serial.print("{\"event\":\"error\",\"msg\":\"json_parse_failed\"}\n");
    return;
  }
  if (doc.containsKey("on")) {
    outputOn = doc["on"] ? true : false;
    if (!outputOn) { ampA = 0; ampB = 0; }
  }
  if (doc.containsKey("fA")) { freqA = doc["fA"].as<double>(); update_phase_increments(); }
  if (doc.containsKey("fB")) { freqB = doc["fB"].as<double>(); update_phase_increments(); }
  if (doc.containsKey("aA")) { ampA = constrain(doc["aA"].as<float>(), 0.0, 1.0); }
  if (doc.containsKey("aB")) { ampB = constrain(doc["aB"].as<float>(), 0.0, 1.0); }
  if (doc.containsKey("cal")) { HX_CAL = doc["cal"].as<float>(); Serial.print(String("{\"event\":\"calibrated\",\"cal\":") + HX_CAL + String("}\n")); }
  if (doc.containsKey("sweep")) {
    // sweep request received; for safety we don't perform automated sweeps on device by default
    Serial.print("{\"event\":\"info\",\"msg\":\"sweep_requested\"}\n");
  }
}

float read_weight(){
  if (!scale.is_ready()) return NAN;
  long sum = 0;
  const int N = 3;
  for (int i=0;i<N;i++) sum += scale.read();
  float grams = (float)(sum / (float)N) * HX_CAL;
  return grams;
}

float read_accel_mag(){
  sensors_event_t event;
  if (accel.begin()){
    accel.getEvent(&event);
    float mag = sqrtf(event.acceleration.x*event.acceleration.x + event.acceleration.y*event.acceleration.y + event.acceleration.z*event.acceleration.z);
    return mag;
  }
  return NAN;
}

unsigned long lastReport = 0;
void setup(){
  Serial.begin(115200);
  delay(200);
  init_wavetable();
  i2s_init();
  update_phase_increments();
  scale.begin(HX_DT, HX_SCK);
  if(!accel.begin()){
    Serial.println("{\"accel\":false}");
  } else {
    accel.setRange(ADXL345_RANGE_16_G);
  }
  // announce readiness and firmware version
  Serial.println("{\"event\":\"ready\",\"fw\":\"esp32_wavetable_v1.0\"}");
}

void loop(){
  // Serial input handling: accumulate until newline and parse
  while (Serial.available()) {
    char c = Serial.read();
    if (c == '\\n') {
      serialBuf.trim();
      if (serialBuf.length() > 0) {
        handleCommandJson(serialBuf);
      }
      serialBuf = "";
    } else {
      serialBuf += c;
      if (serialBuf.length() > 512) serialBuf = serialBuf.substring(serialBuf.length()-512); // keep buffer bounded
    }
  }

  if (outputOn) {
    generate_and_write_samples(FRAMES_PER_CHUNK);
  } else {
    delay(5);
  }

  unsigned long ms = millis();
  if (ms - lastReport >= 50){
    lastReport = ms;
    float weight = read_weight();
    float accmag = read_accel_mag();
    // telemetry JSON
    StaticJsonDocument<256> out;
    out["t_ms"] = ms;
    if (!isnan(weight)) out["w"] = weight;
    else out["w"] = nullptr;
    if (!isnan(accmag)) out["acc"] = accmag;
    else out["acc"] = nullptr;
    out["fA"] = freqA;
    out["fB"] = freqB;
    out["on"] = outputOn?1:0;
    char buf[256];
    size_t n = serializeJson(out, buf, sizeof(buf));
    Serial.println(buf);
  }
}
