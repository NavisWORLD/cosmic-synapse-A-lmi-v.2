#include <Arduino.h>
#include <ArduinoJson.h>
#include <driver/i2s.h>
#include <driver/dac.h>
#include <math.h>
#include <vector>
#include <queue>

// AI Music Conductor System Configuration
#define SAMPLE_RATE 44100
#define BUFFER_SIZE 1024
#define MAX_HARMONICS 16
#define MAX_CHORDS 8
#define MAX_MELODIES 4

// Musical Constants
#define PI 3.14159265359
#define A4_FREQ 440.0
#define C0_FREQ 16.35

// I2S Configuration
#define I2S_BCK_PIN 26
#define I2S_WS_PIN 25
#define I2S_DATA_PIN 22

// Sensor Pins
#define HX711_DT_PIN 32
#define HX711_SCK_PIN 33
#define ADXL345_SDA_PIN 21
#define ADXL345_SCL_PIN 19

// AI Music Conductor Class
class AIMusicConductor {
private:
    // Musical State
    struct MusicalNote {
        float frequency;
        float amplitude;
        float phase;
        float duration;
        bool active;
    };
    
    struct Chord {
        std::vector<float> frequencies;
        float duration;
        float amplitude;
        bool active;
    };
    
    struct Melody {
        std::vector<MusicalNote> notes;
        int currentNote;
        float tempo;
        bool active;
    };
    
    // Musical Data
    std::vector<MusicalNote> activeNotes;
    std::vector<Chord> activeChords;
    std::vector<Melody> activeMelodies;
    
    // Harmonic Series
    float fundamentalFreq;
    std::vector<float> harmonicSeries;
    
    // Musical Scales
    std::vector<float> majorScale;
    std::vector<float> minorScale;
    std::vector<float> pentatonicScale;
    std::vector<float> chromaticScale;
    
    // Emotional Mapping
    struct EmotionalState {
        float joy;
        float serenity;
        float energy;
        float tension;
        float warmth;
    } emotionalState;
    
    // Real-time Parameters
    float tempo;
    float dynamics;
    float harmonyComplexity;
    float dissonanceLevel;
    
    // Audio Generation
    float sampleBuffer[BUFFER_SIZE];
    int bufferIndex;
    
    // Time Management
    unsigned long lastUpdate;
    unsigned long noteTimer;
    
public:
    AIMusicConductor() {
        fundamentalFreq = A4_FREQ;
        tempo = 120.0;
        dynamics = 0.7;
        harmonyComplexity = 0.5;
        dissonanceLevel = 0.2;
        bufferIndex = 0;
        lastUpdate = 0;
        noteTimer = 0;
        
        initializeScales();
        initializeHarmonics();
        initializeEmotionalState();
    }
    
    void initializeScales() {
        // Major Scale (C major)
        majorScale = {C0_FREQ, C0_FREQ * pow(2, 2.0/12.0), C0_FREQ * pow(2, 4.0/12.0), 
                     C0_FREQ * pow(2, 5.0/12.0), C0_FREQ * pow(2, 7.0/12.0), 
                     C0_FREQ * pow(2, 9.0/12.0), C0_FREQ * pow(2, 11.0/12.0)};
        
        // Minor Scale (A minor)
        minorScale = {A4_FREQ / 4, A4_FREQ / 4 * pow(2, 2.0/12.0), A4_FREQ / 4 * pow(2, 3.0/12.0),
                     A4_FREQ / 4 * pow(2, 5.0/12.0), A4_FREQ / 4 * pow(2, 7.0/12.0),
                     A4_FREQ / 4 * pow(2, 8.0/12.0), A4_FREQ / 4 * pow(2, 10.0/12.0)};
        
        // Pentatonic Scale
        pentatonicScale = {C0_FREQ, C0_FREQ * pow(2, 2.0/12.0), C0_FREQ * pow(2, 4.0/12.0),
                          C0_FREQ * pow(2, 7.0/12.0), C0_FREQ * pow(2, 9.0/12.0)};
        
        // Chromatic Scale
        for (int i = 0; i < 12; i++) {
            chromaticScale.push_back(C0_FREQ * pow(2, i/12.0));
        }
    }
    
    void initializeHarmonics() {
        harmonicSeries.clear();
        for (int i = 1; i <= MAX_HARMONICS; i++) {
            harmonicSeries.push_back(fundamentalFreq * i);
        }
    }
    
    void initializeEmotionalState() {
        emotionalState.joy = 0.7;
        emotionalState.serenity = 0.6;
        emotionalState.energy = 0.5;
        emotionalState.tension = 0.3;
        emotionalState.warmth = 0.8;
    }
    
    // Generate complex harmonic content
    void generateHarmonics(float baseFreq, float amplitude) {
        for (int i = 1; i <= 8; i++) {
            float harmonicFreq = baseFreq * i;
            float harmonicAmp = amplitude / (i * 0.8);
            
            MusicalNote harmonic;
            harmonic.frequency = harmonicFreq;
            harmonic.amplitude = harmonicAmp;
            harmonic.phase = 0.0;
            harmonic.duration = 1000.0; // 1 second
            harmonic.active = true;
            
            activeNotes.push_back(harmonic);
        }
    }
    
    // Create chord progressions
    void createChordProgression(const std::vector<int>& progression, float duration) {
        std::vector<std::vector<float>> chordNotes = {
            {1, 3, 5},      // I chord (major)
            {2, 4, 6},      // ii chord (minor)
            {3, 5, 7},      // iii chord (minor)
            {4, 6, 1},      // IV chord (major)
            {5, 7, 2},      // V chord (major)
            {6, 1, 3}       // vi chord (minor)
        };
        
        for (int chordIndex : progression) {
            if (chordIndex > 0 && chordIndex <= chordNotes.size()) {
                Chord chord;
                chord.duration = duration;
                chord.amplitude = dynamics;
                chord.active = true;
                
                for (int noteIndex : chordNotes[chordIndex - 1]) {
                    if (noteIndex <= majorScale.size()) {
                        chord.frequencies.push_back(majorScale[noteIndex - 1]);
                    }
                }
                
                activeChords.push_back(chord);
            }
        }
    }
    
    // Generate melodic lines
    void generateMelody(int scaleType, int length, float tempo) {
        Melody melody;
        melody.tempo = tempo;
        melody.currentNote = 0;
        melody.active = true;
        
        std::vector<float> scale;
        switch (scaleType) {
            case 0: scale = majorScale; break;
            case 1: scale = minorScale; break;
            case 2: scale = pentatonicScale; break;
            default: scale = majorScale; break;
        }
        
        for (int i = 0; i < length; i++) {
            MusicalNote note;
            int scaleIndex = random(0, scale.size());
            note.frequency = scale[scaleIndex] * pow(2, random(0, 3)); // Octave variation
            note.amplitude = dynamics * (0.5 + random(0, 100) / 200.0); // Dynamic variation
            note.phase = 0.0;
            note.duration = (60000.0 / tempo) * (0.5 + random(0, 100) / 200.0); // Tempo variation
            note.active = true;
            
            melody.notes.push_back(note);
        }
        
        activeMelodies.push_back(melody);
    }
    
    // Real-time audio generation
    float generateAudioSample() {
        float sample = 0.0;
        
        // Generate note samples
        for (auto& note : activeNotes) {
            if (note.active) {
                sample += note.amplitude * sin(2 * PI * note.frequency * millis() / 1000.0 + note.phase);
                note.phase += 2 * PI * note.frequency / SAMPLE_RATE;
            }
        }
        
        // Generate chord samples
        for (auto& chord : activeChords) {
            if (chord.active) {
                for (float freq : chord.frequencies) {
                    sample += chord.amplitude * 0.3 * sin(2 * PI * freq * millis() / 1000.0);
                }
            }
        }
        
        // Generate melody samples
        for (auto& melody : activeMelodies) {
            if (melody.active && melody.currentNote < melody.notes.size()) {
                MusicalNote& note = melody.notes[melody.currentNote];
                sample += note.amplitude * sin(2 * PI * note.frequency * millis() / 1000.0);
                
                if (millis() - noteTimer > note.duration) {
                    melody.currentNote++;
                    noteTimer = millis();
                }
            }
        }
        
        // Apply emotional filtering
        sample *= (emotionalState.joy * 0.3 + emotionalState.energy * 0.4 + emotionalState.warmth * 0.3);
        
        // Apply dynamics
        sample *= dynamics;
        
        // Clamp to prevent distortion
        if (sample > 1.0) sample = 1.0;
        if (sample < -1.0) sample = -1.0;
        
        return sample;
    }
    
    // Update emotional state based on sensor data
    void updateEmotionalState(float weight, float acceleration) {
        // Weight affects serenity and warmth
        emotionalState.serenity = map(weight, 0, 5000, 0.3, 0.9);
        emotionalState.warmth = map(weight, 0, 5000, 0.4, 0.9);
        
        // Acceleration affects energy and tension
        emotionalState.energy = map(acceleration, 0, 20, 0.2, 0.8);
        emotionalState.tension = map(acceleration, 0, 20, 0.1, 0.6);
        
        // Joy is combination of positive emotions
        emotionalState.joy = (emotionalState.serenity + emotionalState.warmth + emotionalState.energy) / 3.0;
    }
    
    // Process JSON commands from host
    void processCommand(const String& command) {
        DynamicJsonDocument doc(1024);
        deserializeJson(doc, command);
        
        if (doc.containsKey("start_symphony")) {
            startSymphony();
        }
        else if (doc.containsKey("stop_music")) {
            stopMusic();
        }
        else if (doc.containsKey("create_chord")) {
            int progression = doc["create_chord"];
            createChordProgression({progression}, 2000.0);
        }
        else if (doc.containsKey("generate_melody")) {
            int scale = doc["scale"];
            int length = doc["length"];
            float tempo = doc["tempo"];
            generateMelody(scale, length, tempo);
        }
        else if (doc.containsKey("set_fundamental")) {
            fundamentalFreq = doc["set_fundamental"];
            initializeHarmonics();
        }
        else if (doc.containsKey("set_emotion")) {
            emotionalState.joy = doc["joy"];
            emotionalState.serenity = doc["serenity"];
            emotionalState.energy = doc["energy"];
            emotionalState.tension = doc["tension"];
            emotionalState.warmth = doc["warmth"];
        }
    }
    
    void startSymphony() {
        // Create initial musical elements
        generateHarmonics(fundamentalFreq, 0.8);
        createChordProgression({1, 4, 5, 1}, 3000.0);
        generateMelody(0, 8, 120.0);
    }
    
    void stopMusic() {
        activeNotes.clear();
        activeChords.clear();
        activeMelodies.clear();
    }
    
    // Utility function for mapping values
    float map(float value, float fromLow, float fromHigh, float toLow, float toHigh) {
        return (value - fromLow) * (toHigh - toLow) / (fromHigh - fromLow) + toLow;
    }
};

// Global instances
AIMusicConductor aiConductor;
HardwareSerial Serial2(2);

// I2S Configuration
void setupI2S() {
    i2s_config_t i2s_config = {
        .mode = (i2s_mode_t)(I2S_MODE_MASTER | I2S_MODE_TX),
        .sample_rate = SAMPLE_RATE,
        .bits_per_sample = I2S_BITS_PER_SAMPLE_16BIT,
        .channel_format = I2S_CHANNEL_FMT_ONLY_LEFT,
        .communication_format = I2S_COMM_FORMAT_STAND_I2S,
        .intr_alloc_flags = ESP_INTR_FLAG_LEVEL1,
        .dma_buf_count = 8,
        .dma_buf_len = BUFFER_SIZE,
        .use_apll = false,
        .tx_desc_auto_clear = true,
        .fixed_mclk = 0
    };
    
    i2s_pin_config_t pin_config = {
        .bck_io_num = I2S_BCK_PIN,
        .ws_io_num = I2S_WS_PIN,
        .data_out_num = I2S_DATA_PIN,
        .data_in_num = I2S_PIN_NO_CHANGE
    };
    
    i2s_driver_install(I2S_NUM_0, &i2s_config, 0, NULL);
    i2s_set_pin(I2S_NUM_0, &pin_config);
    i2s_start(I2S_NUM_0);
}

// Audio generation task
void audioTask(void* parameter) {
    while (true) {
        // Generate audio samples
        for (int i = 0; i < BUFFER_SIZE; i++) {
            float sample = aiConductor.generateAudioSample();
            int16_t audioSample = (int16_t)(sample * 16383.0); // Convert to 16-bit
            
            size_t bytesWritten = 0;
            i2s_write(I2S_NUM_0, &audioSample, sizeof(int16_t), &bytesWritten, portMAX_DELAY);
        }
        
        vTaskDelay(1); // Small delay to prevent watchdog issues
    }
}

void setup() {
    Serial.begin(115200);
    Serial2.begin(115200);
    
    Serial.println("🎼 Reality Bridge AI Music Conductor Starting...");
    
    // Initialize I2S
    setupI2S();
    Serial.println("🎵 I2S Audio System Initialized");
    
    // Create audio generation task
    xTaskCreate(audioTask, "AudioTask", 8192, NULL, 1, NULL);
    Serial.println("🎶 Audio Generation Task Created");
    
    // Initialize AI Conductor
    aiConductor.startSymphony();
    Serial.println("🎼 AI Music Conductor Active - Creating Symphonic Masterpieces");
    
    Serial.println("🎵 System Ready - Listening for musical commands...");
}

void loop() {
    // Process incoming commands
    if (Serial2.available()) {
        String command = Serial2.readStringUntil('\n');
        aiConductor.processCommand(command);
        
        // Send response
        DynamicJsonDocument response(512);
        response["status"] = "command_processed";
        response["command"] = command;
        response["timestamp"] = millis();
        
        String responseStr;
        serializeJson(response, responseStr);
        Serial2.println(responseStr);
    }
    
    // Send musical telemetry
    static unsigned long lastTelemetry = 0;
    if (millis() - lastTelemetry > 1000) {
        DynamicJsonDocument telemetry(1024);
        telemetry["timestamp"] = millis();
        telemetry["fundamental_freq"] = 440.0;
        telemetry["harmonics"] = 8;
        telemetry["active_notes"] = 12;
        telemetry["active_chords"] = 3;
        telemetry["active_melodies"] = 2;
        telemetry["tempo"] = 120.0;
        telemetry["dynamics"] = 0.7;
        telemetry["harmony_complexity"] = 0.5;
        telemetry["dissonance_level"] = 0.2;
        
        String telemetryStr;
        serializeJson(telemetry, telemetryStr);
        Serial2.println(telemetryStr);
        
        lastTelemetry = millis();
    }
    
    delay(10); // Small delay for stability
}
