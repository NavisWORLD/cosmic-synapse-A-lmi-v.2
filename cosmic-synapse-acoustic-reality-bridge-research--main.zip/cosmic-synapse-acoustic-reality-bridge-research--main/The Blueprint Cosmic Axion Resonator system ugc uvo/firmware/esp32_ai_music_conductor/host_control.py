#!/usr/bin/env python3
"""
Reality Bridge AI Music Conductor - Host Control Script
Advanced musical intelligence system for creating symphonic masterpieces
"""

import serial
import json
import time
import threading
import numpy as np
from datetime import datetime
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
import tkinter as tk
from tkinter import ttk, messagebox
import queue

class AIMusicConductorHost:
    def __init__(self, port='/dev/ttyUSB0', baud=115200):
        self.port = port
        self.baud = baud
        self.serial_conn = None
        self.is_connected = False
        self.telemetry_queue = queue.Queue()
        self.command_queue = queue.Queue()
        
        # Musical state
        self.current_harmony = 'classical'
        self.fundamental_freq = 440.0
        self.tempo = 120.0
        self.dynamics = 0.7
        self.harmony_complexity = 0.5
        self.dissonance_level = 0.2
        
        # Emotional mapping
        self.emotional_state = {
            'joy': 0.7,
            'serenity': 0.6,
            'energy': 0.5,
            'tension': 0.3,
            'warmth': 0.8
        }
        
        # Real-time data
        self.telemetry_data = {
            'timestamps': [],
            'frequencies': [],
            'harmonics': [],
            'active_notes': [],
            'tempo': [],
            'dynamics': []
        }
        
        self.setup_gui()
        
    def setup_gui(self):
        """Initialize the graphical user interface"""
        self.root = tk.Tk()
        self.root.title("🎼 Reality Bridge AI Music Conductor")
        self.root.geometry("1200x800")
        self.root.configure(bg='#1e3c72')
        
        # Create main frames
        self.create_connection_frame()
        self.create_musical_controls_frame()
        self.create_harmony_frame()
        self.create_emotional_frame()
        self.create_telemetry_frame()
        self.create_visualization_frame()
        
    def create_connection_frame(self):
        """Create connection control frame"""
        conn_frame = ttk.LabelFrame(self.root, text="🔌 Connection", padding=10)
        conn_frame.grid(row=0, column=0, columnspan=2, sticky="ew", padx=10, pady=5)
        
        ttk.Label(conn_frame, text="Port:").grid(row=0, column=0, padx=5)
        self.port_var = tk.StringVar(value=self.port)
        ttk.Entry(conn_frame, textvariable=self.port_var, width=15).grid(row=0, column=1, padx=5)
        
        ttk.Label(conn_frame, text="Baud:").grid(row=0, column=2, padx=5)
        self.baud_var = tk.StringVar(value=str(self.baud))
        ttk.Entry(conn_frame, textvariable=self.baud_var, width=10).grid(row=0, column=3, padx=5)
        
        self.connect_btn = ttk.Button(conn_frame, text="Connect", command=self.connect)
        self.connect_btn.grid(row=0, column=4, padx=10)
        
        self.disconnect_btn = ttk.Button(conn_frame, text="Disconnect", command=self.disconnect, state="disabled")
        self.disconnect_btn.grid(row=0, column=5, padx=5)
        
    def create_musical_controls_frame(self):
        """Create musical control frame"""
        music_frame = ttk.LabelFrame(self.root, text="🎵 Musical Controls", padding=10)
        music_frame.grid(row=1, column=0, columnspan=2, sticky="ew", padx=10, pady=5)
        
        # Fundamental frequency
        ttk.Label(music_frame, text="Fundamental Frequency (Hz):").grid(row=0, column=0, padx=5)
        self.freq_var = tk.DoubleVar(value=self.fundamental_freq)
        freq_scale = ttk.Scale(music_frame, from_=20, to=2000, variable=self.freq_var, 
                              orient="horizontal", length=200, command=self.update_fundamental)
        freq_scale.grid(row=0, column=1, padx=5)
        ttk.Label(music_frame, textvariable=self.freq_var).grid(row=0, column=2, padx=5)
        
        # Tempo control
        ttk.Label(music_frame, text="Tempo (BPM):").grid(row=1, column=0, padx=5)
        self.tempo_var = tk.DoubleVar(value=self.tempo)
        tempo_scale = ttk.Scale(music_frame, from_=40, to=200, variable=self.tempo_var, 
                               orient="horizontal", length=200, command=self.update_tempo)
        tempo_scale.grid(row=1, column=1, padx=5)
        ttk.Label(music_frame, textvariable=self.tempo_var).grid(row=1, column=2, padx=5)
        
        # Dynamics control
        ttk.Label(music_frame, text="Dynamics:").grid(row=2, column=0, padx=5)
        self.dynamics_var = tk.DoubleVar(value=self.dynamics)
        dynamics_scale = ttk.Scale(music_frame, from_=0.0, to=1.0, variable=self.dynamics_var, 
                                  orient="horizontal", length=200, command=self.update_dynamics)
        dynamics_scale.grid(row=2, column=1, padx=5)
        ttk.Label(music_frame, textvariable=self.dynamics_var).grid(row=2, column=2, padx=5)
        
        # Control buttons
        btn_frame = ttk.Frame(music_frame)
        btn_frame.grid(row=3, column=0, columnspan=3, pady=10)
        
        ttk.Button(btn_frame, text="🎼 Start Symphony", command=self.start_symphony).pack(side="left", padx=5)
        ttk.Button(btn_frame, text="🎵 Generate Harmony", command=self.generate_harmony).pack(side="left", padx=5)
        ttk.Button(btn_frame, text="🎶 Create Melody", command=self.create_melody).pack(side="left", padx=5)
        ttk.Button(btn_frame, text="⏹️ Stop Music", command=self.stop_music).pack(side="left", padx=5)
        
    def create_harmony_frame(self):
        """Create harmony selection frame"""
        harmony_frame = ttk.LabelFrame(self.root, text="🎼 Harmony Intelligence", padding=10)
        harmony_frame.grid(row=2, column=0, sticky="ew", padx=10, pady=5)
        
        harmonies = [
            ("🎻 Classical", "classical"),
            ("💕 Romantic", "romantic"),
            ("🎷 Jazz", "jazz"),
            ("🔊 Electronic", "electronic"),
            ("🌍 World", "world"),
            ("🎨 Avant-Garde", "avant-garde")
        ]
        
        self.harmony_var = tk.StringVar(value=self.current_harmony)
        for i, (label, value) in enumerate(harmonies):
            ttk.Radiobutton(harmony_frame, text=label, variable=self.harmony_var, 
                           value=value, command=self.update_harmony).grid(row=i//2, column=i%2, sticky="w", padx=5)
        
    def create_emotional_frame(self):
        """Create emotional control frame"""
        emotion_frame = ttk.LabelFrame(self.root, text="🎭 Emotional Expression", padding=10)
        emotion_frame.grid(row=2, column=1, sticky="ew", padx=10, pady=5)
        
        emotions = ['joy', 'serenity', 'energy', 'tension', 'warmth']
        self.emotion_vars = {}
        
        for i, emotion in enumerate(emotions):
            ttk.Label(emotion_frame, text=f"{emotion.title()}:").grid(row=i, column=0, padx=5, sticky="w")
            var = tk.DoubleVar(value=self.emotional_state[emotion])
            self.emotion_vars[emotion] = var
            scale = ttk.Scale(emotion_frame, from_=0.0, to=1.0, variable=var, 
                             orient="horizontal", length=150, command=lambda v, e=emotion: self.update_emotion(e, v))
            scale.grid(row=i, column=1, padx=5)
            ttk.Label(emotion_frame, textvariable=var).grid(row=i, column=2, padx=5)
        
    def create_telemetry_frame(self):
        """Create telemetry display frame"""
        telemetry_frame = ttk.LabelFrame(self.root, text="📊 Real-Time Telemetry", padding=10)
        telemetry_frame.grid(row=3, column=0, columnspan=2, sticky="ew", padx=10, pady=5)
        
        self.telemetry_text = tk.Text(telemetry_frame, height=8, width=80, bg='black', fg='green', font=('Courier', 10))
        self.telemetry_text.pack(fill="both", expand=True)
        
    def create_visualization_frame(self):
        """Create real-time visualization frame"""
        viz_frame = ttk.LabelFrame(self.root, text="🎨 Musical Visualization", padding=10)
        viz_frame.grid(row=4, column=0, columnspan=2, sticky="ew", padx=10, pady=5)
        
        # Create matplotlib figure
        self.fig, (self.ax1, self.ax2) = plt.subplots(1, 2, figsize=(12, 4))
        self.fig.patch.set_facecolor('#1e3c72')
        
        # Frequency spectrum plot
        self.ax1.set_title('Frequency Spectrum', color='white')
        self.ax1.set_xlabel('Frequency (Hz)', color='white')
        self.ax1.set_ylabel('Amplitude', color='white')
        self.ax1.set_facecolor('#1e3c72')
        self.ax1.grid(True, alpha=0.3)
        
        # Harmonic series plot
        self.ax2.set_title('Harmonic Series', color='white')
        self.ax2.set_xlabel('Harmonic Number', color='white')
        self.ax2.set_ylabel('Frequency (Hz)', color='white')
        self.ax2.set_facecolor('#1e3c72')
        self.ax2.grid(True, alpha=0.3)
        
        # Embed matplotlib in tkinter
        from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
        self.canvas = FigureCanvasTkAgg(self.fig, viz_frame)
        self.canvas.draw()
        self.canvas.get_tk_widget().pack(fill="both", expand=True)
        
    def connect(self):
        """Establish serial connection"""
        try:
            self.serial_conn = serial.Serial(
                port=self.port_var.get(),
                baudrate=int(self.baud_var.get()),
                timeout=1
            )
            self.is_connected = True
            self.connect_btn.config(state="disabled")
            self.disconnect_btn.config(state="normal")
            
            # Start telemetry thread
            self.telemetry_thread = threading.Thread(target=self.telemetry_loop, daemon=True)
            self.telemetry_thread.start()
            
            self.log_telemetry("Connected to Reality Bridge AI Music Conductor")
            messagebox.showinfo("Connection", "Successfully connected to AI Music Conductor!")
            
        except Exception as e:
            messagebox.showerror("Connection Error", f"Failed to connect: {str(e)}")
            
    def disconnect(self):
        """Close serial connection"""
        if self.serial_conn:
            self.serial_conn.close()
            self.is_connected = False
            self.connect_btn.config(state="normal")
            self.disconnect_btn.config(state="disabled")
            self.log_telemetry("Disconnected from AI Music Conductor")
            
    def send_command(self, command):
        """Send JSON command to device"""
        if self.is_connected and self.serial_conn:
            try:
                command_str = json.dumps(command) + '\n'
                self.serial_conn.write(command_str.encode('utf-8'))
                self.log_telemetry(f"Sent command: {command}")
            except Exception as e:
                self.log_telemetry(f"Error sending command: {str(e)}")
                
    def start_symphony(self):
        """Start the AI symphony"""
        command = {"start_symphony": True}
        self.send_command(command)
        
    def stop_music(self):
        """Stop all music"""
        command = {"stop_music": True}
        self.send_command(command)
        
    def generate_harmony(self):
        """Generate harmonic content"""
        command = {"create_chord": 1}
        self.send_command(command)
        
    def create_melody(self):
        """Create melodic line"""
        command = {
            "generate_melody": True,
            "scale": 0,  # Major scale
            "length": 8,
            "tempo": self.tempo_var.get()
        }
        self.send_command(command)
        
    def update_fundamental(self, value):
        """Update fundamental frequency"""
        freq = float(value)
        command = {"set_fundamental": freq}
        self.send_command(command)
        
    def update_tempo(self, value):
        """Update tempo"""
        self.tempo = float(value)
        
    def update_dynamics(self, value):
        """Update dynamics"""
        self.dynamics = float(value)
        
    def update_harmony(self):
        """Update harmony style"""
        self.current_harmony = self.harmony_var.get()
        self.log_telemetry(f"Harmony style changed to: {self.current_harmony}")
        
    def update_emotion(self, emotion, value):
        """Update emotional state"""
        self.emotional_state[emotion] = float(value)
        command = {"set_emotion": self.emotional_state}
        self.send_command(command)
        
    def log_telemetry(self, message):
        """Log telemetry message"""
        timestamp = datetime.now().strftime("%H:%M:%S")
        log_entry = f"[{timestamp}] {message}\n"
        
        self.telemetry_text.insert(tk.END, log_entry)
        self.telemetry_text.see(tk.END)
        
        # Keep only last 100 lines
        lines = self.telemetry_text.get("1.0", tk.END).split('\n')
        if len(lines) > 100:
            self.telemetry_text.delete("1.0", f"{len(lines)-100}.0")
            
    def telemetry_loop(self):
        """Main telemetry processing loop"""
        while self.is_connected and self.serial_conn:
            try:
                if self.serial_conn.in_waiting:
                    line = self.serial_conn.readline().decode('utf-8').strip()
                    if line:
                        try:
                            data = json.loads(line)
                            self.process_telemetry(data)
                        except json.JSONDecodeError:
                            self.log_telemetry(f"Invalid JSON: {line}")
                            
            except Exception as e:
                self.log_telemetry(f"Telemetry error: {str(e)}")
                break
                
            time.sleep(0.01)
            
    def process_telemetry(self, data):
        """Process incoming telemetry data"""
        if 'timestamp' in data:
            self.telemetry_data['timestamps'].append(data['timestamp'])
            
        if 'fundamental_freq' in data:
            self.telemetry_data['frequencies'].append(data['fundamental_freq'])
            
        if 'harmonics' in data:
            self.telemetry_data['harmonics'].append(data['harmonics'])
            
        if 'active_notes' in data:
            self.telemetry_data['active_notes'].append(data['active_notes'])
            
        if 'tempo' in data:
            self.telemetry_data['tempo'].append(data['tempo'])
            
        if 'dynamics' in data:
            self.telemetry_data['dynamics'].append(data['dynamics'])
            
        # Keep only last 100 data points
        max_points = 100
        for key in self.telemetry_data:
            if len(self.telemetry_data[key]) > max_points:
                self.telemetry_data[key] = self.telemetry_data[key][-max_points:]
                
        # Update visualization
        self.update_visualization()
        
    def update_visualization(self):
        """Update real-time visualization"""
        try:
            # Clear previous plots
            self.ax1.clear()
            self.ax2.clear()
            
            # Frequency spectrum
            if self.telemetry_data['frequencies']:
                freqs = np.array(self.telemetry_data['frequencies'])
                amps = np.array(self.telemetry_data['dynamics'])
                
                self.ax1.plot(freqs, amps, 'g-', linewidth=2)
                self.ax1.set_title('Frequency Spectrum', color='white')
                self.ax1.set_xlabel('Frequency (Hz)', color='white')
                self.ax1.set_ylabel('Amplitude', color='white')
                self.ax1.set_facecolor('#1e3c72')
                self.ax1.grid(True, alpha=0.3)
                
            # Harmonic series
            if self.telemetry_data['harmonics']:
                harmonic_nums = list(range(1, len(self.telemetry_data['harmonics']) + 1))
                harmonic_freqs = [self.fundamental_freq * i for i in harmonic_nums]
                
                self.ax2.bar(harmonic_nums, harmonic_freqs, color='cyan', alpha=0.7)
                self.ax2.set_title('Harmonic Series', color='white')
                self.ax2.set_xlabel('Harmonic Number', color='white')
                self.ax2.set_ylabel('Frequency (Hz)', color='white')
                self.ax2.set_facecolor('#1e3c72')
                self.ax2.grid(True, alpha=0.3)
                
            # Update canvas
            self.canvas.draw()
            
        except Exception as e:
            self.log_telemetry(f"Visualization error: {str(e)}")
            
    def run(self):
        """Start the GUI main loop"""
        self.root.mainloop()

def main():
    """Main function"""
    print("🎼 Reality Bridge AI Music Conductor - Host Control System")
    print("Starting advanced musical intelligence interface...")
    
    # Create and run the host control system
    host = AIMusicConductorHost()
    host.run()

if __name__ == "__main__":
    main()
