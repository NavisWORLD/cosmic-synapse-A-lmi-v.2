Methods summary (short):
- Randomized control trials, baseline blocks, accelerometer artifact rejection, Mann-Whitney and bootstrap CIs, regression against accel.
- See README.md and firmware_spec.md for detailed protocol and I/O.
