KiCad Starter Project
- Import schematic parts and place footprints following docs/schematic_ascii.txt
- Create sheets and netlist, then pcb
- This folder is a scaffold only; open in KiCad and proceed with normal PCB design workflow.
