# ESP32 Firmware JSON I/O Contract (Reality Bridge)

This document describes the JSON messages (newline-delimited) exchanged between Host (browser/app) and the ESP32 device via USB Serial. Messages are UTF-8, one JSON object per line.

## From Host → ESP32 (commands)
- **Enable / disable output**
  ```json
  {"on": 1}        // start output
  {"on": 0}        // stop output
  ```

- **Set tone parameters (channel A / B)**
  ```json
  {"fA": 432.0, "aA": 0.6, "phaseA": 0.0}
  {"fB": 864.0, "aB": 0.3, "phaseB": 1.57}
  ```
  - `fA`, `fB`: frequency in Hz (float)
  - `aA`, `aB`: amplitude 0.0..1.0 (float)
  - `phaseA`, `phaseB`: optional phase offset radians (float)

- **Sweep command (server-side scheduler)**
  ```json
  {"sweep": {"ch": "A", "from": 420, "to": 444, "step": 1, "dwell": 3, "repeats": 2}}
  ```
  - Device may perform sweep or host may drive repeated commands.

- **Set calibration / misc**
  ```json
  {"cal": 1.234}   // HX711 calibration constant
  {"led": 1}       // optional status LED
  {"reset": 1}     // software reset (optional)
  ```

## From ESP32 → Host (telemetry)
Device periodically (e.g., 20 Hz) emits newline-separated JSON lines with these keys:

- **Core telemetry (every ~50 ms)**
  ```json
  {
    "t_ms": 1690000000000,
    "w": 123.456,               // weight in grams (float) or null
    "acc": 9.812,               // accel magnitude (m/s^2) or null
    "fA": 432.0, "fB": 864.0,   // current tone freqs
    "on": 1                     // 1 or 0
  }
  ```

- **Event messages**
  ```json
  {"event":"ready"}
  {"event":"error","msg":"HX711 not ready"}
  {"event":"calibrated","cal":1.234}
  ```

## Latency & Timestamping
- `t_ms` should be in epoch ms (UTC) from device clock. Host may re-timestamp upon receipt for synchronization; keep both timestamps when possible.
- Use monotonic timestamps for aligning audio metrics and sensor data.

## Notes & Recommendations
- Use simple JSON only — avoid complex nested objects to ease parsing on host. Use newline delimiter for framing.
- Keep telemetry frequency moderate (20–50 Hz) to avoid saturating USB serial while ensuring sufficient temporal resolution.
- Include device firmware version in initial `{"event":"ready","fw":"v1.0"}` message.
