# Lab Notebook Entry — Reality Bridge Run 001

**Project:** Reality Bridge / Genesis X
**Date:** YYYY-MM-DD
**Operator:** [your name]

## Objective
Measure whether dual-sine resonance correlates with changes in apparent mass of a small test object.

## Setup
- ESP32 (I2S) -> PCM5102A -> Amp -> Exciter
- Load cell + HX711, ADXL345 on scale frame
- Browser UI + logger running at localhost
- Baseline warmup: 20 min

## Notes
- HX711 CAL: ___
- Baseline mean: ___ g; baseline sigma: ___ g
- Trial mode: randomized, N=24 pairs, T_s=30s
