
## PCB Enhancements (Rev A1)
- Added **mounting holes (M3)** at four corners.
- Added **silkscreen pin labels** near each header footprint.
- Added **GND copper pours** on top and bottom. In KiCad, press **B** to refill after edits.
- Placed **reference route guides** on Eco1 layer (use as hints, then route on F.Cu/B.Cu).
- Use **Update PCB from Schematic** to bring nets over, then run **DRC**.

## BOM with MPNs
See `hardware/BOM_with_MPN.csv` for manufacturer part numbers and suggested suppliers.

## Assembly Guide
Open `hardware/assembly_guide.html` in your browser for an interactive checklist with an SVG board overlay.


## Fab scripts
Tools to generate Gerbers and transform pick-and-place files are in `tools/fab_scripts`.
Run them on a machine that has KiCad installed.
