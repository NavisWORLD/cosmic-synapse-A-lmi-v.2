Fabrication Package Instructions
================================

This package contains everything a PCB fab + assembly house (e.g., JLCPCB, PCBWay) needs.

Steps for JLCPCB (2-layer board example):
-----------------------------------------
1. Upload Gerber ZIP: hardware/kicad/reality_bridge/reality_bridge_fab/Gerbers/reality_bridge.Gerber.zip
2. Board parameters:
   - Layers: 2
   - Thickness: 1.6mm FR4
   - Copper weight: 1oz
   - Finish: HASL (lead-free preferred)
   - Solder mask: Green (default)
   - Silkscreen: White
   - Min hole size: 0.3mm (OK)
   - Via tenting: Yes
   - Edge plating: No
   - Surface finish: HASL
   - Panelization: No (single board)
3. Upload BOM (in /hardware/kicad/reality_bridge/reality_bridge_bom.csv).
4. Upload Pick-and-Place CSV (in /hardware/kicad/reality_bridge/reality_bridge_pick_place.csv).
5. Select SMT Assembly (Top side only, unless you add bottom-side parts).
6. Confirm part availability (cross-check manufacturer part numbers).
7. Approve placement preview.
8. Place order.

Validation checklist after Gerber generation:
---------------------------------------------
- Ensure Gerbers include: F.Cu, B.Cu, F.SilkS, B.SilkS, F.Mask, B.Mask, Edge.Cuts
- Ensure drill file (.drl) is included
- Open Gerbers in JLCPCB previewer to confirm silkscreen labels and mounting holes
- Check ground copper pours are filled
- Verify pin labels visible on silkscreen

Output package tree (for fab house):
------------------------------------
- Gerbers/    (final manufacturing files)
- BOM/        (CSV with MPNs)
- PnP/        (Pick-and-place CSV)
- README      (this file)

