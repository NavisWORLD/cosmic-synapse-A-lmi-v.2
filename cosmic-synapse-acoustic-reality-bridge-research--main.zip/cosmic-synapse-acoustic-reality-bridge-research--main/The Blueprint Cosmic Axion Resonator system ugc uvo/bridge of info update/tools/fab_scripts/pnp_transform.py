\
#!/usr/bin/env python3
\"\"\"pnp_transform.py
Transform KiCad PnP CSV to manufacturer's required format (simple example).
Usage: python pnp_transform.py input_kicad_pnp.csv output_manufacturer.csv
\"\"\"
import sys, csv
if len(sys.argv) < 3:
    print('Usage: pnp_transform.py input.csv output.csv'); sys.exit(1)
inp, outp = sys.argv[1], sys.argv[2]
with open(inp, newline='') as f_in, open(outp, 'w', newline='') as f_out:
    r = csv.DictReader(f_in)
    fieldnames = ['Designator','Comment','Footprint','Mid X','Mid Y','Rotation','Layer']
    w = csv.DictWriter(f_out, fieldnames=fieldnames)
    w.writeheader()
    for row in r:
        # map KiCad columns to simple fab columns (assumes standard kicad_pcb plot output)
        w.writerow({
            'Designator': row.get('Ref', row.get('Designator','')),
            'Comment': row.get('Value',''),
            'Footprint': row.get('Footprint',''),
            'Mid X': row.get('PosX',''),
            'Mid Y': row.get('PosY',''),
            'Rotation': row.get('Rot','0'),
            'Layer': row.get('Side','Top')
        })
print('Wrote', outp)
