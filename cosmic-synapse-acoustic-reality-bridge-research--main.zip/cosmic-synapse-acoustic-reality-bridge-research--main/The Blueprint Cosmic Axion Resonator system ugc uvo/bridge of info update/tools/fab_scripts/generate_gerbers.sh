\
#!/usr/bin/env bash
# generate_gerbers.sh
# Usage: ./generate_gerbers.sh path/to/project.kicad_pcb output_dir
# Requires: KiCad (pcbnew) installed and on PATH (kicad6/7), or run from KiCad scripting console.
set -e
PCB="$1"
OUTDIR="$2"
if [ -z "$PCB" ] || [ -z "$OUTDIR" ]; then
  echo "Usage: $0 path/to/reality_bridge.kicad_pcb out/gerbers"
  exit 2
fi
mkdir -p "$OUTDIR"
# Example using pcbnew command-line exporter (KiCad 6+ has pcbnew scripting)
# If you have 'kicad-cli' installed: 
# kicad-cli pcb plot "$PCB" --output "$OUTDIR" --format gerber --layers F.Cu,B.Cu,F.SilkS,B.SilkS,F.Mask,B.Mask,Edge.Cuts
# Alternatively, use pcbnew_python script (works when KiCad Python modules are available):
python3 - <<PY
import pcbnew, sys, os
pcb_path = r"${PCB}"
out_dir = r"${OUTDIR}"
board = pcbnew.LoadBoard(pcb_path)
pctl = pcbnew.PLOT_CONTROLLER(board)
popt = pctl.GetPlotOptions()
popt.SetOutputDirectory(out_dir)
popt.SetPlotFrameRef(False)
popt.SetPlotValue(True)
popt.SetPlotReference(True)
popt.SetUseGerberAttributes(True)
popt.SetPlotFootprintValues(True)
# Layers to plot
layers = [
    (pcbnew.F_Cu, 'F.Cu'),
    (pcbnew.B_Cu, 'B.Cu'),
    (pcbnew.F_SilkS, 'F.SilkS'),
    (pcbnew.B_SilkS, 'B.SilkS'),
    (pcbnew.F_Mask, 'F.Mask'),
    (pcbnew.B_Mask, 'B.Mask'),
    (pcbnew.Edge_Cuts, 'Edge.Cuts')
]
for layer, name in layers:
    pctl.SetLayer(layer)
    pctl.OpenPlotfile(name, pcbnew.PLOT_FORMAT_GERBER, name)
    pctl.PlotLayer()
# Generate drill
drlwriter = pcbnew.EXCELLON_WRITER(board)
drlwriter.SetOptions(format=pcbnew.EXCELLON_WRITER.D_FORMAT_TBD, minimalHeader=False, merge_PTH=True)
drlwriter.CreateDrillandMapFilesSet(out_dir, True, False)
print('Gerbers and drill files written to', out_dir)
PY
echo "Done. Gerbers in $OUTDIR"
