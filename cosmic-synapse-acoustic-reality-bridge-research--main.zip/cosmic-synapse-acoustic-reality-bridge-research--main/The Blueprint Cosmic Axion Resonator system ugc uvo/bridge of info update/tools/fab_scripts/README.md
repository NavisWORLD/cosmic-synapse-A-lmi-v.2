Fab Script README
=================

This folder contains helper scripts to generate Gerber + drill files from a KiCad PCB file.
You must run these scripts on a machine with KiCad installed (the scripts call KiCad's Python API).

Example:
  ./generate_gerbers.sh path/to/reality_bridge.kicad_pcb out/gerbers

If you have kicad-cli (KiCad 7+), prefer:
  kicad-cli pcb plot path/to/reality_bridge.kicad_pcb --output out/gerbers --format gerber --layers F.Cu,B.Cu,F.SilkS,B.SilkS,F.Mask,B.Mask,Edge.Cuts
