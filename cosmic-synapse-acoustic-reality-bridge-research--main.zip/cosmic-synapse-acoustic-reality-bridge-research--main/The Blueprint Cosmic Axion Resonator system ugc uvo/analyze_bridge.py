#!/usr/bin/env python3
"""analyze_bridge.py — simple analysis script (CLI)
Usage: python analyze_bridge.py path/to/csv
"""
import sys, os, pandas as pd, numpy as np
from scipy.stats import ranksums
def main(path):
    df = pd.read_csv(path)
    # expected columns: deviceDelta_g, deviceAccel_g, matchGate, trial_phase, t_ms
    df = df.dropna(subset=['deviceDelta_g','deviceAccel_g','matchGate','trial_phase'])
    z = (df['deviceAccel_g'] - df['deviceAccel_g'].mean()) / df['deviceAccel_g'].std()
    df_clean = df[abs(z) < 6]
    target = df_clean[df_clean['trial_phase']=='target']['deviceDelta_g'].values
    control= df_clean[df_clean['trial_phase']=='control']['deviceDelta_g'].values
    print('Samples (clean):', len(df_clean), 'target:', len(target), 'control:', len(control))
    if len(target)>5 and len(control)>5:
        stat,p = ranksums(target, control)
        print('ranksums stat,p:', stat, p)
    else:
        print('Not enough data for test')
if __name__=='__main__':
    if len(sys.argv)<2:
        print('Usage: analyze_bridge.py path/to/csv')
    else:
        main(sys.argv[1])
