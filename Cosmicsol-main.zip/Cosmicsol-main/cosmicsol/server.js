#!/usr/bin/env node
/**
 * Genesis X Local Web Server
 * Run this to serve the Genesis X application and avoid CORS issues.
 *
 * Usage:
 *     node server.js
 *
 * Or install http-server globally:
 *     npm install -g http-server
 *     http-server -p 8000 -c-1
 *
 * Then visit: http://localhost:8000/genesis_x_solana_bonk_v_next_standalone.html
 */

const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');
const url = require('url');

const PORT = 8000;
const HOST = 'localhost';

// MIME types for different file extensions
const MIME_TYPES = {
    '.html': 'text/html',
    '.css': 'text/css',
    '.js': 'application/javascript',
    '.json': 'application/json',
    '.png': 'image/png',
    '.jpg': 'image/jpeg',
    '.jpeg': 'image/jpeg',
    '.gif': 'image/gif',
    '.svg': 'image/svg+xml',
    '.ico': 'image/x-icon'
};

// Proxy function for Solana API requests
function proxySolanaRequest(req, res, targetUrl) {
    console.log(`🔗 Proxying to Solana API: ${targetUrl}`);

    const parsedTarget = url.parse(targetUrl);
    const options = {
        hostname: parsedTarget.hostname,
        port: parsedTarget.port || 443,
        path: parsedTarget.path + (parsedTarget.query ? '?' + parsedTarget.query : ''),
        method: req.method,
        headers: {
            ...req.headers,
            'Origin': undefined, // Remove origin to avoid CORS issues
            'Referer': undefined,
            'User-Agent': 'GenesisX-Proxy/1.0'
        }
    };

    const proxyReq = https.request(options, (proxyRes) => {
        // Copy response headers
        res.writeHead(proxyRes.statusCode, {
            ...proxyRes.headers,
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
            'Access-Control-Allow-Headers': '*'
        });

        // Pipe the response
        proxyRes.pipe(res);
    });

    proxyReq.on('error', (error) => {
        console.error('Proxy error:', error);
        res.writeHead(500, {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        });
        res.end(JSON.stringify({ error: 'Proxy error', message: error.message }));
    });

    // Pipe the request body if present
    if (req.method === 'POST' || req.method === 'PUT') {
        req.pipe(proxyReq);
    } else {
        proxyReq.end();
    }
}

const server = http.createServer((req, res) => {
    console.log(`${new Date().toISOString()} - ${req.method} ${req.url}`);

    // Parse the URL
    const parsedUrl = url.parse(req.url);
    let pathname = parsedUrl.pathname;

    // Handle Solana API proxy requests
    if (pathname.startsWith('/solana-api/')) {
        const apiPath = pathname.substring('/solana-api/'.length);
        const query = parsedUrl.query ? '?' + parsedUrl.query : '';
        const targetUrl = `https://api.mainnet-beta.solana.com/${apiPath}${query}`;
        proxySolanaRequest(req, res, targetUrl);
        return;
    }

    // Handle Devnet API proxy requests
    if (pathname.startsWith('/solana-devnet/')) {
        const apiPath = pathname.substring('/solana-devnet/'.length);
        const query = parsedUrl.query ? '?' + parsedUrl.query : '';
        const targetUrl = `https://api.devnet.solana.com/${apiPath}${query}`;
        proxySolanaRequest(req, res, targetUrl);
        return;
    }

    // Default to index.html for root path
    if (pathname === '/') {
        pathname = '/genesis_x_solana_bonk_v_next_standalone.html';
    }

    // Construct the file path
    const filePath = path.join(__dirname, pathname);

    // Check if the file exists
    fs.access(filePath, fs.constants.F_OK, (err) => {
        if (err) {
            // File not found
            res.writeHead(404, {
                'Content-Type': 'text/html',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
                'Access-Control-Allow-Headers': '*'
            });
            res.end(`
<!DOCTYPE html>
<html>
<head>
    <title>Genesis X - File Not Found</title>
    <style>
        body { font-family: Arial, sans-serif; text-align: center; padding: 50px; background: #0f0f23; color: #00ff41; }
        .error { color: #ff4444; }
        .info { color: #00aaff; }
    </style>
</head>
<body>
    <h1 class="error">404 - File Not Found</h1>
    <p>The requested file <code>${pathname}</code> was not found.</p>
    <p class="info">Try: <a href="/genesis_x_solana_bonk_v_next_standalone.html">Genesis X Main App</a></p>
</body>
</html>`);
            return;
        }

        // File exists, read and serve it
        fs.readFile(filePath, (err, data) => {
            if (err) {
                res.writeHead(500, {
                    'Content-Type': 'text/html',
                    'Access-Control-Allow-Origin': '*'
                });
                res.end('<h1>500 - Internal Server Error</h1>');
                return;
            }

            // Get the file extension
            const ext = path.extname(filePath);
            const contentType = MIME_TYPES[ext] || 'text/plain';

            // Set CORS headers
            res.writeHead(200, {
                'Content-Type': contentType,
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
                'Access-Control-Allow-Headers': '*',
                'Cache-Control': 'no-cache'
            });

            res.end(data);
        });
    });
});

// Handle OPTIONS requests for CORS
server.on('request', (req, res) => {
    if (req.method === 'OPTIONS') {
        res.writeHead(200, {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
            'Access-Control-Allow-Headers': '*'
        });
        res.end();
        return;
    }
});

server.listen(PORT, HOST, () => {
    console.log('🚀 Genesis X Local Web Server');
    console.log('='.repeat(50));
    console.log(`Server running at: http://${HOST}:${PORT}`);
    console.log(`Serving files from: ${__dirname}`);
    console.log();
    console.log('🌐 Open your browser and visit:');
    console.log(`http://${HOST}:${PORT}/genesis_x_solana_bonk_v_next_standalone.html`);
    console.log();
    console.log('✨ Full Genesis X functionality enabled!');
    console.log('🔧 No more CORS issues!');
    console.log();
    console.log('Press Ctrl+C to stop the server');
    console.log('='.repeat(50));
});

process.on('SIGINT', () => {
    console.log('\n👋 Server stopped by user');
    process.exit(0);
});

process.on('SIGTERM', () => {
    console.log('\n👋 Server stopped');
    process.exit(0);
});
