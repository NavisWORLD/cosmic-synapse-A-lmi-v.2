#!/bin/bash

# Genesis X Local Web Server Launcher
# This script helps you start the local web server to avoid CORS issues

echo "========================================"
echo "🚀 GENESIS X LOCAL WEB SERVER"
echo "========================================"
echo ""
echo "This will start a local web server to serve"
echo "the Genesis X application and avoid CORS issues."
echo ""

# Check if Python is available
if command -v python3 &> /dev/null; then
    PYTHON_CMD="python3"
elif command -v python &> /dev/null; then
    PYTHON_CMD="python"
else
    echo "❌ Python not found. Please install Python and try again."
    echo "Visit: https://python.org"
    exit 1
fi

echo "✅ Python found! Starting server..."
echo ""
echo "========================================"
echo "🌐 SERVER STARTING..."
echo "========================================"
echo ""
echo "Once the server starts, open your browser and visit:"
echo "http://localhost:8000/genesis_x_solana_bonk_v_next_standalone.html"
echo ""
echo "Press Ctrl+C to stop the server"
echo "========================================"

# Start the Python HTTP server
$PYTHON_CMD -m http.server 8000

echo ""
echo "Server stopped. Goodbye! 👋"
