# 🚀 Genesis X - Ultimate Token Creation Platform

**Create tokens from consciousness energy, trade on DEXs, and analyze markets with AI-powered insights!**

## 🌟 Features

- ✅ **Token Creation from Consciousness Energy** - AI-powered token generation
- ✅ **Real Solana Blockchain Integration** - Full SPL token support
- ✅ **DEX Trading with BONK** - Buy/sell tokens on Solana DEXs
- ✅ **AI Market Analytics** - Consciousness-driven market insights
- ✅ **Automated Liquidity Provision** - AMM pool management
- ✅ **Real-time Health Monitoring** - System status tracking
- ✅ **Comprehensive Error Handling** - Production-ready reliability

## 🔧 Quick Start (Avoid CORS Issues)

### Option 1: Python Server (Recommended)
```bash
# Navigate to the project directory
cd /path/to/genesis-x-files

# Start the server
python server.py

# Or use Python's built-in server
python -m http.server 8000
```

### Option 2: Node.js Server
```bash
# Install http-server globally
npm install -g http-server

# Navigate to the project directory
cd /path/to/genesis-x-files

# Start the server
http-server -p 8000 -c-1

# Or run the custom server
node server.js
```

### Option 3: Direct Python Command
```bash
python -m http.server 8000
```

## 🌐 Access the Application

Once the server is running, open your browser and visit:
```
http://localhost:8000/genesis_x_solana_bonk_v_next_standalone.html
```

## 🛠️ Troubleshooting

### CORS Errors
If you see CORS errors, you're running the file directly from your file system. **Always use a local web server!**

### `require is not defined` Error
This happens when trying to run Node.js files in the browser. Use the HTML file instead.

### Connection Issues
- Check your internet connection
- Try different Solana RPC endpoints
- The system automatically tries multiple endpoints

### Wallet Issues
- Install [Phantom Wallet](https://phantom.app/)
- Ensure you're on Solana mainnet-beta
- Refresh the page after connecting wallet

## 🎮 How to Use

### 1. Connect Wallet
- Click "Connect Solana Wallet"
- Approve the connection in Phantom
- Your SOL and BONK balances will appear

### 2. Create Tokens
- Fill in token details (name, symbol, supply)
- Select a meme theme
- Click "Create Token from Consciousness"
- AI uses consciousness field for optimal parameters

### 3. Trade on DEXs
- Enter token address and amount
- Set slippage tolerance
- Buy/Sell with real DEX integration

### 4. Market Analytics
- Click "Analyze User Data & Generate Markets"
- View consciousness field charts
- Get AI-powered trading insights

### 5. Liquidity Management
- Create liquidity pools
- Add liquidity automatically
- Monitor TVL and volume

## 🔧 System Architecture

### Libraries Used
- **@solana/web3.js** - Solana blockchain interaction
- **@solana/spl-token** - Token creation and management
- **Chart.js** - Real-time data visualization
- **Raydium/Jupiter SDK** - DEX integration
- **Phantom Wallet** - Solana wallet integration

### Features
- **Real Token Creation** - Actually mints SPL tokens on Solana
- **Live Trading** - Executes real DEX swaps
- **AI Analytics** - Consciousness-powered market analysis
- **Health Monitoring** - Real-time system diagnostics
- **Error Recovery** - Automatic fallback and restart

## 🌟 Advanced Capabilities

### Token Creation Engine
- Consciousness field integration
- AI-powered parameter optimization
- Meme theme selection
- Metadata generation with traits

### DEX Integration
- Multi-endpoint support
- Automatic slippage calculation
- Price impact analysis
- Transaction confirmation

### Market Analytics
- Real-time consciousness tracking
- AI-powered insights
- Chart visualization
- Predictive analytics

### System Reliability
- Comprehensive error handling
- Automatic health checks
- Emergency fallback mode
- System reset functionality

## 🚨 Important Notes

1. **Always use a local web server** - Direct file opening causes CORS issues
2. **Install Phantom Wallet** - Required for full functionality
3. **Check console logs** - Detailed system status and debugging info
4. **System health** - Monitor the status indicator for optimal performance

## 🎯 What Makes This Revolutionary

- **Consciousness-Driven Tokenomics** - Uses quantum physics simulation for token parameters
- **Real Blockchain Integration** - Actually creates and trades real tokens
- **AI Market Intelligence** - Consciousness-powered trading insights
- **Automated Market Making** - Self-managing liquidity provision
- **Production-Ready Reliability** - Enterprise-level error handling and monitoring

## 📞 Support

If you encounter issues:
1. Check the system logs in the application
2. Ensure you're using a local web server
3. Verify Phantom wallet installation
4. Try refreshing the page
5. Use the system reset button if needed

---

**Genesis X: Where consciousness meets cryptocurrency! 🌟🚀💎**
