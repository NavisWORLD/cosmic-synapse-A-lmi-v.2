#!/usr/bin/env python3
"""
Genesis X Local Web Server
Run this to serve the Genesis X application and avoid CORS issues.

Usage:
    python server.py

Or simply:
    python -m http.server 8000

Then visit: http://localhost:8000/genesis_x_solana_bonk_v_next_standalone.html
"""

import http.server
import socketserver
import os
import sys
from pathlib import Path

class CORSHTTPRequestHandler(http.server.SimpleHTTPRequestHandler):
    def end_headers(self):
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', '*')
        super().end_headers()

    def do_OPTIONS(self):
        self.send_response(200)
        self.end_headers()

def main():
    port = 8000

    # Get the directory where this script is located
    script_dir = Path(__file__).parent

    print("🚀 Genesis X Local Web Server")
    print("=" * 50)
    print(f"Serving files from: {script_dir}")
    print(f"Server will start on: http://localhost:{port}")
    print()
    print("Instructions:")
    print("1. Open your web browser")
    print("2. Visit: http://localhost:8000/genesis_x_solana_bonk_v_next_standalone.html")
    print("3. Enjoy full Genesis X functionality!")
    print()
    print("Press Ctrl+C to stop the server")
    print("=" * 50)

    # Change to the script directory
    os.chdir(script_dir)

    try:
        with socketserver.TCPServer(("", port), CORSHTTPRequestHandler) as httpd:
            print(f"Server started successfully on port {port}")
            httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nServer stopped by user")
        sys.exit(0)
    except OSError as e:
        if e.errno == 98:  # Address already in use
            print(f"Port {port} is already in use. Try a different port:")
            print(f"python -m http.server 8080")
        else:
            print(f"Error starting server: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
